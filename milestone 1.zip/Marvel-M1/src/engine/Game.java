package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import exceptions.*;
import model.abilities.*;
import model.effects.*;
import model.world.*;


public class Game {
	private static ArrayList<Champion> availableChampions;
	private static ArrayList<Ability> availableAbilities;
	private Player firstPlayer;
	private Player secondPlayer;
	private Object[][] board;
	private PriorityQueue turnOrder;
	private boolean firstLeaderAbilityUsed;
	private boolean secondLeaderAbilityUsed;
	private final static int BOARDWIDTH = 5;
	private final static int BOARDHEIGHT = 5;

	public Game(Player first, Player second) {
		firstPlayer = first;
		secondPlayer = second;
		availableChampions = new ArrayList<Champion>();
		availableAbilities = new ArrayList<Ability>();
		board = new Object[BOARDWIDTH][BOARDHEIGHT];
		turnOrder = new PriorityQueue(6);
		this.prepareChampionTurns();
		placeChampions();
		placeCovers();
		firstLeaderAbilityUsed= false;
		secondLeaderAbilityUsed=false;
	}

	public static void loadAbilities(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (line != null) {
			String[] content = line.split(",");
			Ability a = null;
			AreaOfEffect ar = null;
			switch (content[5]) {
			case "SINGLETARGET":
				ar = AreaOfEffect.SINGLETARGET;
				break;
			case "TEAMTARGET":
				ar = AreaOfEffect.TEAMTARGET;
				break;
			case "SURROUND":
				ar = AreaOfEffect.SURROUND;
				break;
			case "DIRECTIONAL":
				ar = AreaOfEffect.DIRECTIONAL;
				break;
			case "SELFTARGET":
				ar = AreaOfEffect.SELFTARGET;
				break;

			}
			Effect e = null;
			if (content[0].equals("CC")) {
				switch (content[7]) {
				case "Disarm":
					e = new Disarm(Integer.parseInt(content[8]));
					break;
				case "Dodge":
					e = new Dodge(Integer.parseInt(content[8]));
					break;
				case "Embrace":
					e = new Embrace(Integer.parseInt(content[8]));
					break;
				case "PowerUp":
					e = new PowerUp(Integer.parseInt(content[8]));
					break;
				case "Root":
					e = new Root(Integer.parseInt(content[8]));
					break;
				case "Shield":
					e = new Shield(Integer.parseInt(content[8]));
					break;
				case "Shock":
					e = new Shock(Integer.parseInt(content[8]));
					break;
				case "Silence":
					e = new Silence(Integer.parseInt(content[8]));
					break;
				case "SpeedUp":
					e = new SpeedUp(Integer.parseInt(content[8]));
					break;
				case "Stun":
					e = new Stun(Integer.parseInt(content[8]));
					break;
				}
			}
			switch (content[0]) {
			case "CC":
				a = new CrowdControlAbility(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[4]),
						Integer.parseInt(content[3]), ar, Integer.parseInt(content[6]), e);
				break;
			case "DMG":
				a = new DamagingAbility(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[4]),
						Integer.parseInt(content[3]), ar, Integer.parseInt(content[6]), Integer.parseInt(content[7]));
				break;
			case "HEL":
				a = new HealingAbility(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[4]),
						Integer.parseInt(content[3]), ar, Integer.parseInt(content[6]), Integer.parseInt(content[7]));
				break;
			}
			availableAbilities.add(a);
			line = br.readLine();
		}
		br.close();
	}

	public static void loadChampions(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (line != null) {
			String[] content = line.split(",");
			Champion c = null;
			switch (content[0]) {
			case "A":
				c = new AntiHero(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]),
						Integer.parseInt(content[4]), Integer.parseInt(content[5]), Integer.parseInt(content[6]),
						Integer.parseInt(content[7]));
				break;

			case "H":
				c = new Hero(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]),
						Integer.parseInt(content[4]), Integer.parseInt(content[5]), Integer.parseInt(content[6]),
						Integer.parseInt(content[7]));
				break;
			case "V":
				c = new Villain(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]),
						Integer.parseInt(content[4]), Integer.parseInt(content[5]), Integer.parseInt(content[6]),
						Integer.parseInt(content[7]));
				break;
			}

			c.getAbilities().add(findAbilityByName(content[8]));
			c.getAbilities().add(findAbilityByName(content[9]));
			c.getAbilities().add(findAbilityByName(content[10]));
			availableChampions.add(c);
			line = br.readLine();
		}
		br.close();
	}

	private static Ability findAbilityByName(String name) {
		for (Ability a : availableAbilities) {
			if (a.getName().equals(name))
				return a;
		}
		return null;
	}

	public void placeCovers() {
		int i = 0;
		while (i < 5) {
			int y = ((int) (Math.random() * (BOARDWIDTH - 2))) + 1;
			int x = (int) (Math.random() * BOARDHEIGHT);

			if (board[x][y] == null) {
				board[x][y] = new Cover(x, y);
				i++;
			}
		}

	}

	public void placeChampions() {
		int i = 1;
		for (Champion c : firstPlayer.getTeam()) {
			board[i][0] = c;
			c.setLocation(new Point(i, 0));
			i++;
		}
		i = 1;
		for (Champion c : secondPlayer.getTeam()) {
			board[i][BOARDHEIGHT - 1] = c;
			c.setLocation(new Point(i, BOARDHEIGHT - 1));
			i++;
		}
	
	}

	public static ArrayList<Champion> getAvailableChampions() {
		return availableChampions;
	}

	public static ArrayList<Ability> getAvailableAbilities() {
		return availableAbilities;
	}

	public Player getFirstPlayer() {
		return firstPlayer;
	}

	public Player getSecondPlayer() {
		return secondPlayer;
	}
	
	public boolean isFriendly(Champion c, Champion target) {
		int t = teamTurn(c);
		int d= teamTurn(target);
		if(t==d)
			return true;
		else
			return false;
	}

	public Object[][] getBoard() {
		return board;
	}

	public PriorityQueue getTurnOrder() {
		return turnOrder;
	}

	public boolean isFirstLeaderAbilityUsed() {
		return firstLeaderAbilityUsed;
	}

	public boolean isSecondLeaderAbilityUsed() {
		return secondLeaderAbilityUsed;
	}

	public static int getBoardwidth() {
		return BOARDWIDTH;
	}

	public static int getBoardheight() {
		return BOARDHEIGHT;
	}
	
	public Champion getCurrentChampion() {
		 return (Champion)turnOrder.peekMin();
	 }
	 
	public boolean checkManhattan (Point a, Point b, int range) {
		if(Math.abs(a.x-b.x)+ Math.abs(a.y-b.y) <= range)
			return true;
		else return false;
	}
	//call in endTurn
	public int findEffect(ArrayList<Effect> applied, String s) {
		int number=-1;
		for(int i= 0; i<applied.size(); i++) {
			if(applied.get(i).getName().equals(s))
				number=i;
		}
		return number;
	}
	
	public Player checkGameOver() {
		 int c1=0;
		 int c2=0;
		 for(int i=0; i<3; i++) {
		 if(firstPlayer.getTeam().get(i).getCondition() == Condition.KNOCKEDOUT) {
			 c1++;
		 }
		 if(secondPlayer.getTeam().get(i).getCondition() == Condition.KNOCKEDOUT) {
			 c2++;
		 }	
		 }
		 if(c1==3)
			 return secondPlayer;
	 	 else {
	 		 if(c2==3)
	 		 	return firstPlayer;
	 		 else
	 			 return null;
	 	 	}
	 }
	
	public void move(Direction d) throws UnallowedMovementException, NotEnoughResourcesException {
		 Champion c= this.getCurrentChampion();
		 if(c.getCondition()==Condition.ROOTED)
			 throw new UnallowedMovementException();
		 Point p= c.getLocation();
		 int x = p.x;
		 int y = p.y;
		 int points=c.getCurrentActionPoints();
		 if(points==0) {
			 throw new  NotEnoughResourcesException();
		 }
		 else {
			 
		 if(d==Direction.UP) {
			 if(y+1<=4) {
			 Point ps=new Point(x,y+1);
			 if(board[y+1][x]==null){
				 c.setLocation(ps);
				 c.setCurrentActionPoints(points-1);
				 board[x][y]=null;
			 }
			 else throw new UnallowedMovementException();
			 }
			 else throw new UnallowedMovementException();
		 	 }
		 if(d==Direction.DOWN) {
			 if(y+1<=4) {
			 Point ps=new Point(x,y-1);
			 if(board[y-1][x]==null){
				 c.setLocation(ps);
				 c.setCurrentActionPoints(points-1);
				 board[x][y]=null;
			 }
			 else throw new UnallowedMovementException();
		 }
			 else throw new UnallowedMovementException();
		 }
		 if(d==Direction.RIGHT) {
			 if(y+1<=4) {
			 Point ps=new Point(x+1,y);
			 if(board[y][x+1]==null){
				 c.setLocation(ps);
				 c.setCurrentActionPoints(points-1);
				 board[x][y]=null;
			 }
			 else throw new UnallowedMovementException();
			 }
			 else throw new UnallowedMovementException();
		 }
		 if(d==Direction.LEFT) {
			 if(y+1<=4) {
			 Point ps=new Point(x-1,y);
			 if(board[y][x-1]==null){
				 c.setLocation(ps);
				 c.setCurrentActionPoints(points-1);
				 board[x][y]=null;
			 }
			 else throw new UnallowedMovementException();
			 }
			 else throw new UnallowedMovementException();
		 }
		 }
	 }
	
	public void attack(Direction d) throws NotEnoughResourcesException, ChampionDisarmedException {
		 //champion's range,action points
		//check brackets
		//handle Disarm, Dodge, Shield
		 Champion c= this.getCurrentChampion();
		 Point p= c.getLocation();
		 int x = p.x;
		 int y = p.y;
		 int points=c.getCurrentActionPoints();
		 int range = c.getAttackRange();
		 int damage = c.getAttackDamage();
		 Damageable target = null;
		 
		 //if disarm
		 for(int i =0; i<c.getAppliedEffects().size(); i++) {
			 if (c.getAppliedEffects().get(i).getName()=="Disarm")
				 throw new ChampionDisarmedException();
		 }
		 //if enough turn points
		 if(points<2) {
			 throw new  NotEnoughResourcesException();
		 }
		 else {
			 c.setCurrentActionPoints(points-2);
			 for(int i = 1; i<=range;i++) {
				 switch (d){
				 case UP:
					 if (board[y+i][x] instanceof Damageable ) {
						  target = (Damageable)board[x][y+i];
					 }
					 break;
				 case DOWN:
					 if (board[y-i][x] instanceof Damageable) {
						  target = (Damageable)board[x][y-i];
					 }
					 break;
					 
				 case RIGHT:
					 if (board[y][x+i] instanceof Damageable) {
						  target = (Damageable)board[x+1][y];
					 }
					 break;
					 
				 case LEFT:
					 if (board[y][x-i] instanceof Damageable ) {
						  target = (Damageable)board[x-1][y];
						
					 }
					 break;

					 default: break;
			 }
			  if(target!=null) {//if he finds the first target break
				  break;
			  }
			 }
			 if (target==null) {
			 }else {
			if(target instanceof Cover) {
				 target.setCurrentHP(target.getCurrentHP()-c.getAttackDamage());
				 c.setCurrentActionPoints(points-2);
				 }
			teamTurn(c);
			if(target instanceof Champion && !this.isFriendly(c,(Champion)target)) {
				//check shield
				//check dodge
				c.setCurrentActionPoints(points-2);
	
				int dodge=-1;
				dodge = findEffect(((Champion)target).getAppliedEffects(),"Dodge");
				if (dodge!=-1)
					dodge=(int) (Math.random()*2+1);
				
				int shield=-1;
				shield = findEffect(((Champion)target).getAppliedEffects(),"Shield");
				if(shield!=-1) {//remove shield and no attack
					
							((Champion)target).getAppliedEffects().get(shield).remove((Champion)target);
							((Champion)target).getAppliedEffects().remove(shield);
						
					
				}
				else { 
					if(dodge ==1) {
					
				}
					else {
				 if ((c instanceof Hero && target instanceof Hero)||(c instanceof AntiHero && target instanceof AntiHero)
						 || (c instanceof Villain && target instanceof Villain)) {
					target.setCurrentHP(target.getCurrentHP()-damage);
					 }
				else {
				    int extradamage = (int)(damage * 1.5);
					target.setCurrentHP(target.getCurrentHP()-extradamage);
					 }
				 
				}
			}
				if(target.getCurrentHP()==0) {	
					Point tar = ((Champion)target).getLocation();
					((Champion)target).setLocation(null);
					board[tar.x][tar.y]=null;
			}
			 
			 
				 
			 }
			}
	 }
}
	
	public int teamTurn(Champion c) {
		for(int i=0; i<3;i++) {
			if(firstPlayer.getTeam().get(i)==c)
				return 1;
			if(secondPlayer.getTeam().get(i)==c)
				return 2;
		}
		return 0;
	}
	
	public void castAbility(Ability a) throws CloneNotSupportedException, NotEnoughResourcesException, AbilityUseException {
		ArrayList <Damageable> d=new ArrayList();
		Champion c = this.getCurrentChampion();
		Point pch = c.getLocation();
		if (c.getMana()>= a.getManaCost()&&c.getCurrentActionPoints()>=a.getRequiredActionPoints()) {
			c.setMana(c.getMana()-a.getManaCost());
			c.setCurrentActionPoints(c.getCurrentActionPoints()-a.getRequiredActionPoints());
			a.setCurrentCooldown(a.getBaseCooldown());
		}
			else {
				throw new NotEnoughResourcesException();
			}
		int silence=-1;
		
		silence=this.findEffect(c.getAppliedEffects(),"Silence");
		if(silence!=-1)
			throw new AbilityUseException() ; //remove shield and no attack
		
		if (a.getCastArea()==AreaOfEffect.SELFTARGET) { //if self target
				 d.add((Damageable)this.getCurrentChampion());
			 }
		
		else {
			if (a.getCastArea()==AreaOfEffect.TEAMTARGET) { //if team target
				
				int team=this.teamTurn(c);
				if (a instanceof HealingAbility) {
					if(team==1) {
						for(int i=0; i<3;i++) {
							Champion t = firstPlayer.getTeam().get(i);
							Point p = t.getLocation();
							if(checkManhattan(pch,p,c.getAttackRange()))
								d.add((Damageable)firstPlayer.getTeam().get(i));
						}
					}
					if(team==2) {
						for(int i=0; i<3;i++) {
							Champion t = secondPlayer.getTeam().get(i);
							Point p = t.getLocation();
							if(checkManhattan(pch,p,c.getAttackRange()))
								d.add((Damageable)secondPlayer.getTeam().get(i));
						}
					}
				}
				if (a instanceof DamagingAbility) {
					
					if(team==1) {
						for(int i=0; i<3;i++) {
							Champion t = secondPlayer.getTeam().get(i);
							int shield=-1;
							
							shield = findEffect(t.getAppliedEffects(),"Shield");
							if(shield!=-1) {//remove shield and no attack
										t.getAppliedEffects().get(shield).remove(t);
										t.getAppliedEffects().remove(shield);
							}
							else { 
							Point p = t.getLocation();
							if(checkManhattan(pch,p,c.getAttackRange()))
								d.add((Damageable)secondPlayer.getTeam().get(i));
							}
						}
					}
					if(team==2) {
						for(int i=0; i<3;i++) {
							Champion t = firstPlayer.getTeam().get(i);
							int shield=-1;
							
							shield = findEffect(t.getAppliedEffects(),"Shield");
							if(shield!=-1) {//remove shield and no attack
										t.getAppliedEffects().get(shield).remove(t);
										t.getAppliedEffects().remove(shield);
							}
							else { 
							Point p = t.getLocation();
							if(checkManhattan(pch,p,c.getAttackRange()))
								d.add((Damageable)firstPlayer.getTeam().get(i));
							}
						}
					}
				}
				if (a instanceof CrowdControlAbility) {
					if (((CrowdControlAbility) a).getEffect().getType()==EffectType.BUFF) {
						if(team==1) {
							for(int i=0; i<3;i++) {
								Champion t = firstPlayer.getTeam().get(i);
								Point p = t.getLocation();
								if(checkManhattan(pch,p,c.getAttackRange()))
									d.add((Damageable)firstPlayer.getTeam().get(i));
							}
						}
						if(team==2) {
							for(int i=0; i<3;i++) {
								Champion t = secondPlayer.getTeam().get(i);
								Point p = t.getLocation();
								if(checkManhattan(pch,p,c.getAttackRange()))
									d.add((Damageable)secondPlayer.getTeam().get(i));
							}
						}
					}
					if (((CrowdControlAbility) a).getEffect().getType()==EffectType.DEBUFF) {
						if(team==1) {
							for(int i=0; i<3;i++) {
								Champion t = secondPlayer.getTeam().get(i);
								Point p = t.getLocation();
								if(checkManhattan(pch,p,c.getAttackRange()))
									d.add((Damageable)secondPlayer.getTeam().get(i));
							}
						}
						if(team==2) {
							for(int i=0; i<3;i++) {
								Champion t = firstPlayer.getTeam().get(i);
								Point p = t.getLocation();
								if(checkManhattan(pch,p,c.getAttackRange()))
									d.add((Damageable)firstPlayer.getTeam().get(i));
							}
						}
					}
				}
				
				}
			
			else {
				if(a.getCastArea()==AreaOfEffect.SURROUND) { //if surround
					 Point location= c.getLocation();
					 int x= location.x;
					 int y= location.y;
					 Point up = new Point(x,y+1);
					 Point down = new Point(x,y-1);
					 Point left = new Point(x-1,y);
					 Point right = new Point(x+1,y);
					 Point upl = new Point(x-1,y+1);
					 Point upr = new Point(x+1,y+1);
					 Point dwnl = new Point(x-1,y-1);
					 Point dwnr = new Point(x-1,y-1);
					 
					 //check if any point is invalid
					 
					 if(up.y<=4 && (board[up.x][up.y]!=null)) {
						 d.add((Damageable)board[up.x][up.y]);
					 }
					 if(down.y>=0 && (board[down.x][down.y]!=null)) {
						 d.add((Damageable)board[down.x][down.y]);
					 }
					 if(left.x>=0 && (board[left.x][left.y]!=null)) {
						 d.add((Damageable)board[left.x][left.y]);
					 }
					 if(right.x<=4 && (board[right.x][right.y]!=null)) {
						 d.add((Damageable)board[right.x][right.y]);
					 }
					 if(upl.y<=4 && upl.x>=0 && (board[upl.x][upl.y]!=null)) {
						 d.add((Damageable)board[upl.x][upl.y]);
					 }
					 if(upr.y<=4 && upl.x<=4 && (board[upr.x][upr.y]!=null)) {
						 d.add((Damageable)board[upr.x][upr.y]);
					 }
					 if(dwnl.y>=0 && dwnl.x>=0 && (board[dwnl.x][dwnl.y]!=null)) {
						 d.add((Damageable)board[dwnl.x][dwnl.y]);
					 }
					 if(dwnr.y>=0 && dwnr.x<=4 &&(board[dwnr.x][dwnr.y]!=null)) {
						 d.add((Damageable)board[dwnr.x][dwnr.y]);
					 }
					 
					 //implement for every type of abilities
					 
					 int team= this.teamTurn(c); //check first or second player
					 
					 if(a instanceof DamagingAbility) {
						
						 if (team == 1) {
							int i=0;
							for(int i1= 0; i1<3; i1++) {
								Champion c1= firstPlayer.getTeam().get(i1);
								
								while(d.get(i)!=null) {
									if (d.get(i) instanceof Champion && (Champion) d.get(i) == c1) {
										d.remove(i);
										}
									else {
										i++;
									}
								}
									
						}
							i=0;
							while(d.get(i)!=null) {
								if (d.get(i) instanceof Champion) {
									Champion m = (Champion) d.get(i);
									int j=0;
									while(m.getAppliedEffects().get(j)!=null) {
									if(m.getAppliedEffects().get(j).getName()=="Shield") {
										Shield s = (Shield) m.getAppliedEffects().get(j);
										d.remove(i);
										s.remove(m);
									}else {
									j++;
										}
									}
								}
							i++;
							}
						}
						 
						if (team == 2) {
							int i=0;
							for(int i1= 0; i1<3; i1++) {
								Champion c1= secondPlayer.getTeam().get(i1);
								while(d.get(i)!=null) {
									if (d.get(i) instanceof Champion && (Champion) d.get(i) == c1) {
										d.remove(i);
									}
								i++;
								}
							}
								i=0;
								while(d.get(i)!=null) {
									if (d.get(i) instanceof Champion) {
										Champion m = (Champion) d.get(i);
										int j=0;
										while(m.getAppliedEffects().get(j)!=null) {
										if(m.getAppliedEffects().get(j).getName()=="Shield") {
											Shield s = (Shield) m.getAppliedEffects().get(j);
											d.remove(i);
											s.remove(m);
										}else {
										j++;
											}
										}
									}
								i++;
								}
							}
						}
					 
					 
					 if(a instanceof HealingAbility) {
						 if (team == 1) {
								int i=0;
								for(int i1= 0; i1<3; i1++) {
									Champion c1= secondPlayer.getTeam().get(i1);
									while(d.get(i)!=null) {
										if ((d.get(i) instanceof Champion && (Champion) d.get(i) == c1)||d.get(i) instanceof Cover) {
											d.remove(i);
										}else {
										i++;
										}
									}
								}	
							}
							if (team == 2) {
								int i=0;
								for(int i1= 0; i1<3; i1++) {
									Champion c1= firstPlayer.getTeam().get(i1);
									while(d.get(i)!=null) {
										if ((d.get(i) instanceof Champion && (Champion) d.get(i) == c1)||d.get(i) instanceof Cover) {
											d.remove(i);
										}else {
										i++;
										}
									}
								}
							}
					 }
					 if(a instanceof CrowdControlAbility) {
						 if (((CrowdControlAbility) a).getEffect().getType()==EffectType.BUFF) {
							 if (team == 1) {
									int i=0;
									for(int i1= 0; i1<3; i1++) {
										Champion c1= secondPlayer.getTeam().get(i1);
										while(d.get(i)!=null) {
											if ((d.get(i) instanceof Champion && (Champion) d.get(i) == c1)||d.get(i) instanceof Cover) {
												d.remove(i);
											}else {
											i++;
											}
										}
									}	
								}
								if (team == 2) {
									int i=0;
									for(int i1= 0; i1<3; i1++) {
										Champion c1= firstPlayer.getTeam().get(i1);
										while(d.get(i)!=null) {
											if ((d.get(i) instanceof Champion && (Champion) d.get(i) == c1)||d.get(i) instanceof Cover) {
												d.remove(i);
											}else {
											i++;
											}
										}
									}
								}
						   }
						 if (((CrowdControlAbility) a).getEffect().getType()==EffectType.DEBUFF) {
							 if (team == 1) {
									int i=0;
									for(int i1= 0; i1<3; i1++) {
										Champion c1= firstPlayer.getTeam().get(i1);
										while(d.get(i)!=null) {
											if ((d.get(i) instanceof Champion && (Champion) d.get(i) == c1)||d.get(i) instanceof Cover) {
												d.remove(i);
											}
											else {
												i++;
												}
										}
									}	
								}
								if (team == 2) {
									int i=0;
									for(int i1= 0; i1<3; i1++) {
										Champion c1= secondPlayer.getTeam().get(i1);
										while(d.get(i)!=null) {
											if ((d.get(i) instanceof Champion && (Champion) d.get(i) == c1)||d.get(i) instanceof Cover) {
												d.remove(i);
											}
											else {
												i++;
												}
										}
									}
								}
						    }
					    }
				    }
				}
			}	 
		a.execute(d);
		}
			//when Silence no casting 
			//when shield
	public void castAbility(Ability a, Direction d) throws NotEnoughResourcesException, AbilityUseException, CloneNotSupportedException, InvalidTargetException {
			int range = a.getCastRange();
			Champion c= this.getCurrentChampion();
			int points= c.getCurrentActionPoints();
			Point pt=c.getLocation();
			int x= pt.x;
			int y= pt.y;
			Damageable target= null;
			
			int silence=-1;
			
			silence=this.findEffect(c.getAppliedEffects(),"Silence");
			if(silence!=-1)
				throw new AbilityUseException() ; // no attack
			else {
				if (c.getMana()>= a.getManaCost()&&c.getCurrentActionPoints()>=a.getRequiredActionPoints()) {
					c.setMana(c.getMana()-a.getManaCost());
					c.setCurrentActionPoints(c.getCurrentActionPoints()-a.getRequiredActionPoints());
					a.setCurrentCooldown(a.getBaseCooldown());
				}
					else {
						throw new NotEnoughResourcesException();
					}
			}
				
				 for(int i = 1; i<=range;i++) {
					 switch (d){
					 case UP:
						 if (board[y+i][x] instanceof Damageable ) {
							  target = (Damageable)board[x][y+i];
						 }
						 break;
					 case DOWN:
						 if (board[y-i][x] instanceof Damageable) {
							  target = (Damageable)board[x][y-i];
						 }
						 break;
						 
					 case RIGHT:
						 if (board[y][x+i] instanceof Damageable) {
							  target = (Damageable)board[x+1][y];
						 }
						 break;
						 
					 case LEFT:
						 if (board[y][x-i] instanceof Damageable ) {
							  target = (Damageable)board[x-1][y];
							
						 }
						 break;

						 default: break;
				 }
					 //if many targets delete if and store in arraylist
				  if(target!=null) //if he finds the first target break
					  break;
				 }
				 ArrayList <Damageable> targets= new ArrayList<>();
				 targets.add(target);
				 
				 if(a instanceof DamagingAbility) {
					if(target instanceof Cover || (target instanceof Champion && !isFriendly(c,(Champion)target))) {
					 a.execute(targets);
					}
					else {
						throw new InvalidTargetException();
					}
				 }
				 
				 if(a instanceof HealingAbility ||(a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType()==EffectType.BUFF )) {
						if(target instanceof Champion) {
							if(isFriendly(((Champion)target),c))
								a.execute(targets);
							else {
								throw new InvalidTargetException();
							}
						}
						else {
							throw new InvalidTargetException();
						}
				 }
				 if (a instanceof CrowdControlAbility && (((CrowdControlAbility)a).getEffect().getType()==EffectType.DEBUFF)){
					 if(target instanceof Champion) {
						 if(!isFriendly(((Champion)target),c))
							 a.execute(targets);
						 else {
							 throw new InvalidTargetException();
						 }
							}
					else {
						throw new InvalidTargetException();
							}			
				 }
		
			
	}

	public void castAbility(Ability a, int x, int y) throws AbilityUseException, NotEnoughResourcesException, CloneNotSupportedException, InvalidTargetException {
		int range = a.getCastRange();
		Champion c= this.getCurrentChampion();
		int points= c.getCurrentActionPoints();
		Point pt=c.getLocation();
		Point tar= new Point(x,y);
		Damageable target= null;
		
		int silence=-1;
		
		silence=this.findEffect(c.getAppliedEffects(),"Silence");
		if(silence!=-1)
			throw new AbilityUseException() ; 
		else {
			if (c.getMana()>= a.getManaCost()&&c.getCurrentActionPoints()>=a.getRequiredActionPoints()) {
				c.setMana(c.getMana()-a.getManaCost());
				c.setCurrentActionPoints(c.getCurrentActionPoints()-a.getRequiredActionPoints());
				a.setCurrentCooldown(a.getBaseCooldown());
			}
				else {
					throw new NotEnoughResourcesException();
				}
		}
		if(board[x][y]!=null) {
			if(this.checkManhattan(pt,tar,range)) {
				target = (Damageable)board[x][y];
				 ArrayList <Damageable> targets= new ArrayList<>();
				 targets.add(target);
				 
				 if(a instanceof DamagingAbility) {
					if(target instanceof Cover || (target instanceof Champion && !isFriendly(c,(Champion)target))) {
					 a.execute(targets);
					}
					else {
						throw new InvalidTargetException();
					}
				 }
				 
				 if(a instanceof HealingAbility ||(a instanceof CrowdControlAbility && ((CrowdControlAbility)a).getEffect().getType()==EffectType.BUFF )) {
						if(target instanceof Champion) {
							if(isFriendly(((Champion)target),c))
								a.execute(targets);
							else {
								throw new InvalidTargetException();
							}
						}
						else {
							throw new InvalidTargetException();
						}
				 }
				 if (a instanceof CrowdControlAbility && (((CrowdControlAbility)a).getEffect().getType()==EffectType.DEBUFF)){
					 if(target instanceof Champion) {
						 if(!isFriendly(((Champion)target),c))
							 a.execute(targets);
						 else {
							 throw new InvalidTargetException();
						 }
							}
					else {
						throw new InvalidTargetException();
							}			
				 }
			}
		}
		else {
			throw new InvalidTargetException();
		}
	
	}

	public void useLeaderAbility() throws LeaderAbilityAlreadyUsedException, LeaderNotCurrentException {
		Champion c= this.getCurrentChampion();
		if (c == this.firstPlayer.getLeader()||c== this.secondPlayer.getLeader()) {
			if(((!this.isFirstLeaderAbilityUsed())&&c== this.firstPlayer.getLeader())||((!this.isSecondLeaderAbilityUsed())&&c== this.secondPlayer.getLeader())) {
				ArrayList <Champion> targets =new ArrayList();
				if (c== this.firstPlayer.getLeader()) {
					this.firstLeaderAbilityUsed=true;
					if(c instanceof Hero ) {
						for(int i =0; i<3; i++) {
							targets.add(this.getFirstPlayer().getTeam().get(i));
						}
					}
					if(c instanceof Villain) {
						for(int i =0; i<3; i++) {
							targets.add(this.getSecondPlayer().getTeam().get(i));
						}
					}
					if(c instanceof AntiHero) {
						for(int i =0; i<3; i++) {
							if(this.getFirstPlayer().getTeam().get(i)!=this.firstPlayer.getLeader())
								targets.add(this.getFirstPlayer().getTeam().get(i));
							if(this.getSecondPlayer().getTeam().get(i)!=this.secondPlayer.getLeader())
								targets.add(this.getSecondPlayer().getTeam().get(i));
							
						}
					}
				}
				
				if (c== this.secondPlayer.getLeader()) {
					this.secondLeaderAbilityUsed=true;
					if(c instanceof Hero ) {
						for(int i =0; i<3; i++) {
							targets.add(this.getSecondPlayer().getTeam().get(i));
						}
					}
					if(c instanceof Villain) {
						for(int i =0; i<3; i++) {
							targets.add(this.getFirstPlayer().getTeam().get(i));
						}
					}
					if(c instanceof AntiHero) {
						for(int i =0; i<3; i++) {
							if(this.getFirstPlayer().getTeam().get(i)!=this.firstPlayer.getLeader())
								targets.add(this.getFirstPlayer().getTeam().get(i));
							if(this.getSecondPlayer().getTeam().get(i)!=this.secondPlayer.getLeader())
								targets.add(this.getSecondPlayer().getTeam().get(i));
							
						}
					}
				}
				
				
			}else throw new LeaderAbilityAlreadyUsedException();
			
		}else throw new  LeaderNotCurrentException();
		 
	 }
	 
	public void endTurn() {
		turnOrder.remove();
		
		if(turnOrder.isEmpty()) {
			prepareChampionTurns();
		}
		
		Champion c = this.getCurrentChampion();
		
		if (c.getCondition()==Condition.INACTIVE) 
			this.endTurn();
		else {
			int i=0;
			while(c.getAppliedEffects().get(i)!=null) {
				Effect e = c.getAppliedEffects().get(i);
				e.setDuration(e.getDuration()-1);
				if(e.getDuration()==0) {
					this.getCurrentChampion().getAppliedEffects().remove(i);
					e.remove(getCurrentChampion());
					
				}
				i++;
			}
			i=0;
			while(c.getAbilities().get(i)!=null) {
				Ability a = c.getAbilities().get(i);
				a.setCurrentCooldown(a.getCurrentCooldown()-1);
				i++;
			}
			c.setCurrentActionPoints(c.getMaxActionPointsPerTurn());
		}
		
		
		
	 }
	 
	private void prepareChampionTurns() {
		 for(int i=0;i<3;i++) {
			 if(this.getFirstPlayer().getTeam().get(i).getCondition()!=Condition.KNOCKEDOUT)
				 turnOrder.insert((Comparable)this.getFirstPlayer().getTeam().get(i));
			 if(this.getSecondPlayer().getTeam().get(i).getCondition()!=Condition.KNOCKEDOUT)
			 	turnOrder.insert((Comparable)this.getSecondPlayer().getTeam().get(i));
		 }
	 }
	 
}

