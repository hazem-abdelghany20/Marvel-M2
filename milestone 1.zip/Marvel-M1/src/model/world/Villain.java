package model.world;

import java.util.ArrayList;

public class Villain extends Champion {

	public Villain(String name, int maxHP, int maxMana, int actions, int speed, int attackRange, int attackDamage) {
		super(name, maxHP, maxMana, actions, speed, attackRange, attackDamage);

	}

	public int compareTo(Champion o) {
		return super.compareTo(o);
	}
	
	public void useLeaderAbility(ArrayList<Champion> targets) {
		int i=0;
		while(targets.get(i)!=null) {
			double percent = targets.get(i).getCurrentHP()/targets.get(i).getMaxHP();
			if(percent<0.3) {
				targets.get(i).setCondition(Condition.KNOCKEDOUT);
				targets.get(i).setCurrentHP(0);
				targets.get(i).setLocation(null);
			}
		i++;
		}
	}

}
