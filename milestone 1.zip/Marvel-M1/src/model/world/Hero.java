package model.world;

import java.util.ArrayList;
import model.effects.*;

public class Hero extends Champion {

	public Hero(String name, int maxHP, int maxMana, int actions, int speed, int attackRange, int attackDamage) {
		super(name, maxHP, maxMana, actions, speed, attackRange, attackDamage);

	}

	public int compareTo(Champion o) {
		return super.compareTo(o);
	}
	
	public void useLeaderAbility(ArrayList<Champion> targets) {
		int i=0;
		while(targets.get(i)!=null) {
			Embrace em = new Embrace(2);
			Champion t = (Champion) targets.get(i);
			em.apply(t);
			t.getAppliedEffects().add(em);
			
			int j=0;
			while(t.getAppliedEffects().get(j)!=null) {
				if (t.getAppliedEffects().get(j).getType()==EffectType.DEBUFF) {
					t.getAppliedEffects().get(j).remove(t);
				}
				else {
					j++;
				}
			}
			i++;
		}
	}
}
