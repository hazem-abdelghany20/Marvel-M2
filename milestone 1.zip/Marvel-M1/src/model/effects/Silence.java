package model.effects;

import model.world.Champion;

public class Silence extends Effect {

	public Silence( int duration) {
		super("Silence", duration, EffectType.DEBUFF);
		
	}
	
	public void apply(Champion c) {
		int y= c.getMaxActionPointsPerTurn()+2;
		c.setMaxActionPointsPerTurn(y);	
		int z=c.getCurrentActionPoints()+2;
		c.setCurrentActionPoints(z);	
	}
	 public void remove(Champion c) {
			int y= c.getMaxActionPointsPerTurn()-2;
			c.setMaxActionPointsPerTurn(y);
			int z=c.getCurrentActionPoints()-2;
			c.setCurrentActionPoints(z);
		 }
}
