package model.effects;

import model.world.Champion;

public class Embrace extends Effect {
	

	public Embrace(int duration) {
		super("Embrace", duration, EffectType.BUFF);
	}

	 public void apply(Champion c) {
		 int x= (int)(c.getCurrentHP()+(c.getMaxHP()*0.2));
		 c.setCurrentHP(x);
		 int y= (int)(c.getMana()*1.2);
		 c.setMana(y);
		 int z=(int)(c.getSpeed()*1.2);
		 c.setSpeed(z);
		 int a=(int)(c.getAttackDamage()*1.2);
		 c.setAttackDamage(a);
		 
		 
	 }
	 public void remove(Champion c) {
		 int z=(int)(c.getSpeed()/1.2);
		 c.setSpeed(z);
		 int a=(int)(c.getAttackDamage()/1.2);
		 c.setAttackDamage(a);
		 int i=0;

	 }
}
