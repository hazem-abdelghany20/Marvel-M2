package model.effects;

import model.world.Champion;

public class Shock extends Effect {

	public Shock(int duration) {
		super("Shock", duration, EffectType.DEBUFF);
		
	}

	
	public void apply(Champion c) {
		int x= (int)(c.getSpeed()*0.9);
		c.setSpeed(x);
		int v = (int)(c.getAttackDamage()*0.9);
		c.setAttackDamage(v);
		int y= c.getMaxActionPointsPerTurn()-1;
		c.setMaxActionPointsPerTurn(y);
		int z=c.getCurrentActionPoints()-1;
		c.setCurrentActionPoints(z);
		
	}
	 public void remove(Champion c) {
			int x= (int)(c.getSpeed()/0.9);
			c.setSpeed(x);
			int v = (int)(c.getAttackDamage()/0.9);
			c.setAttackDamage(v);
			int y= c.getMaxActionPointsPerTurn()+1;
			c.setMaxActionPointsPerTurn(y);
			int z=c.getCurrentActionPoints()+1;
			c.setCurrentActionPoints(z);
			
		 }
	 
}
