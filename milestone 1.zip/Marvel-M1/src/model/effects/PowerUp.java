package model.effects;

import java.util.ArrayList;

import model.abilities.Ability;
import model.abilities.*;
import model.world.Champion;

public class PowerUp extends Effect {
	

	public PowerUp(int duration) {
		super("PowerUp", duration, EffectType.BUFF);
		
	}
	
	 public void apply(Champion c) {
		 ArrayList<Ability> Abilities = new ArrayList<Ability>(c.getAbilities());
		 int i = 0;
		 while(Abilities.get(i)!=null) {
			Ability a = Abilities.get(i);
			 if (a instanceof DamagingAbility) {
				DamagingAbility d = (DamagingAbility) a;
				int n = (int)(d.getDamageAmount()*1.2);
				d.setDamageAmount(n);;
			 }
			 if (a instanceof HealingAbility) {
				HealingAbility h = (HealingAbility) a;
				int n = (int)(h.getHealAmount()*1.2);
				h.setHealAmount(n);
			 }
		i++;
		 }
	 }
	 public void remove(Champion c) {
		 ArrayList<Ability> Abilities = new ArrayList<Ability>(c.getAbilities());
		 int i = 0;
		 while(Abilities.get(i)!=null) {
			Ability a = Abilities.get(i);
			 if (a instanceof DamagingAbility) {
				DamagingAbility d = (DamagingAbility) a;
				int n = (int)(d.getDamageAmount()/1.2);
				d.setDamageAmount(n);;
			 }
			 if (a instanceof HealingAbility) {
				HealingAbility h = (HealingAbility) a;
				int n = (int)(h.getHealAmount()/1.2);
				h.setHealAmount(n);
			 }
			 i++;
		 }
	 }
	 
	
}
