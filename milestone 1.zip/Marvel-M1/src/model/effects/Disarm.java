package model.effects;

import java.util.ArrayList;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.DamagingAbility;
import model.world.Champion;

public class Disarm extends Effect {
	
	private int oldpower;

	public Disarm(int duration) {
		super("Disarm", duration, EffectType.DEBUFF);
		
	}
	
	 public void apply(Champion c) {
		 //Target cannot use normal attacks.
		 DamagingAbility Punch= new DamagingAbility("Punch",0,1,1,AreaOfEffect.SINGLETARGET,1,50);
		 c.getAbilities().add(Punch);
		 
		 
	 }
	 
	 public void remove(Champion c) {
		 for(int i=0; i<c.getAbilities().size();i++) {
			 if(c.getAbilities().get(i).getName()== "Punch")
				 c.getAbilities().remove(i);
		 	}
		 }
		
	 
	 }
