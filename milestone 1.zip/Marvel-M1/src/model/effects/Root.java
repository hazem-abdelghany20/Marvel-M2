package model.effects;

import model.world.Champion;
import model.world.Condition;

public class Root extends Effect {
	
	public Root( int duration) {
		super("Root", duration, EffectType.DEBUFF);
		
	}
	
	 public void apply(Champion c) {
		 boolean flag = false;
		 for(int i=0; i<c.getAppliedEffects().size();i++) {
			 if(c.getAppliedEffects().get(i).getName()=="Stun")
				 flag = true;
		 }
		 if(!flag)
			 c.setCondition(Condition.ROOTED);
	 }
	 public void remove(Champion c) {
		 boolean flag = false;
		 for(int i=0; i<c.getAppliedEffects().size();i++) {
			 if(c.getAppliedEffects().get(i).getName()=="ROOT" || c.getAppliedEffects().get(i).getName()=="STUN" )
				 flag = true;
		 }
		 if(!flag)
			 c.setCondition(Condition.ACTIVE);
	 }
	 

}
